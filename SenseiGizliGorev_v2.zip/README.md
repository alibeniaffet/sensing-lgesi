# 🥷 Sensei: Gizli Görev (v2.0)

Sensei temalı sosyal çıkarım oyunu. Şu an botlarla tek cihazda tam oynanabilir.

## Özellikler
- 4–10 oyuncu, Shinobi / Sabotajcı rolleri
- 3 mini görev: Kablo paneli, Enerji çekirdeği (hafıza), Sinyal (zamanlama)
- Sabotajcı aksiyonları: etkisiz hale getir, sabotaj, sahte görev
- Ceset raporlama, acil toplantı, bot sohbeti ve oylama
- Hayalet modu, istatistik kaydı, oda lobisi (demo)

## APK derleme (GitHub)
1. Bu klasörün İÇİNDEKİLERİ repository köküne yükle (`app/`, `.github/`, `build.gradle.kts` ...).
2. GitHub > Actions > "Sensei APK Build" > Run workflow.
3. Bitince çalışmanın altındaki Artifacts > `Sensei-Gizli-Gorev-APK` dosyasını indir, zip'ten çıkan APK'yı telefona kur.

Release olarak yayınlamak için tag at: `git tag v2.0 && git push origin v2.0`
