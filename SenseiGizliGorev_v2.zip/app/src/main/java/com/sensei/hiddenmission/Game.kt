package com.sensei.hiddenmission

import kotlin.random.Random

enum class Role { SHINOBI, SABOTAJCI }
enum class Winner { NONE, SHINOBI, SABOTAJCI }

class Player(val id: Int, val name: String, val isHuman: Boolean) {
    var role: Role = Role.SHINOBI
    var alive: Boolean = true
    var tasksDone: Int = 0
    var revealed: Boolean = false
}

sealed class Event {
    data class TaskDone(val by: Player) : Event()
    data class Kill(val victim: Player, val killer: Player) : Event()
    data class Report(val by: Player, val victim: Player) : Event()
    data class Sabotage(val by: Player) : Event()
    data class GameOver(val winner: Winner) : Event()
}

class MeetingResult(val summary: String, val message: String, val ejected: Player?)

class Game(humanName: String, botNames: List<String>) {

    companion object {
        const val TASKS_PER_PLAYER = 3
        val BOT_NAMES = listOf(
            "Hanzo", "Kenji", "Ryu", "Akira", "Sakura", "Yuki",
            "Taro", "Mika", "Daichi", "Rin", "Kaito", "Hana"
        )
    }

    val human = Player(0, humanName, true)
    val players: List<Player>
    val tasksTotal: Int
    var tasksDone = 0
    var meetingsLeft = 2
    var body: Player? = null
    var humanKillCd = 20
    var humanSabCd = 15

    private var killer: Player? = null
    private var botKillCd = 40
    private var botSabCd = 55
    private val suspicion = mutableMapOf<Int, Int>()

    private val accuseLines = listOf(
        "{n} çok sessiz kaldı, bana şüpheli geliyor.",
        "Görev yaparken {n}'i hiç görmedim. Sence de garip değil mi?",
        "Bence sabotajcı {n}. Oyumu ona vereceğim!",
        "{n}'in davranışları tuhaftı, gözüm üzerinde.",
        "{n}'i son gördüğümde yalnızdı ve acele ediyordu.",
        "Birisi kaçamak davranıyor... {n}, açıkla kendini!"
    )
    private val defendLines = listOf(
        "Ben masumum, görevlerime bakın!",
        "Bana değil, gerçek sabotajcıya bakın!",
        "Beni suçlamak sabotajcının işine yarar.",
        "Bütün zamanımı görevlerle geçirdim, yemin ederim!"
    )
    private val neutralLines = listOf(
        "Emin değilim... Elimizde yeterli kanıt yok.",
        "Ben bir şey görmedim. Dikkatli oy verelim.",
        "Acele etmeyelim, yanlış kişiyi atarsak biter."
    )

    init {
        val list = mutableListOf(human)
        botNames.forEachIndexed { i, n -> list.add(Player(i + 1, n, false)) }
        players = list.shuffled()
        val sabCount = if (players.size >= 7) 2 else 1
        val sabs = mutableSetOf<Int>()
        if (Random.nextFloat() < 0.3f) sabs.add(human.id)
        while (sabs.size < sabCount) sabs.add(players.random().id)
        for (p in players) {
            if (p.id in sabs) p.role = Role.SABOTAJCI
        }
        tasksTotal = (players.size - sabCount) * TASKS_PER_PLAYER
    }

    fun crewAlive(): Int = players.count { it.alive && it.role == Role.SHINOBI }
    fun sabAlive(): Int = players.count { it.alive && it.role == Role.SABOTAJCI }

    fun winner(): Winner {
        if (sabAlive() == 0) return Winner.SHINOBI
        if (tasksDone >= tasksTotal) return Winner.SHINOBI
        if (sabAlive() >= crewAlive()) return Winner.SABOTAJCI
        return Winner.NONE
    }

    private fun check(ev: MutableList<Event>) {
        val w = winner()
        if (w != Winner.NONE) ev.add(Event.GameOver(w))
    }

    private fun loseTasks(n: Int) {
        for (i in 0 until n) {
            val p = players
                .filter { !it.isHuman && it.alive && it.role == Role.SHINOBI && it.tasksDone > 0 }
                .randomOrNull() ?: return
            p.tasksDone--
            tasksDone--
        }
    }

    // ---------- Her saniye çalışan oyun döngüsü ----------
    fun tick(): List<Event> {
        val ev = mutableListOf<Event>()
        if (humanKillCd > 0) humanKillCd--
        if (humanSabCd > 0) humanSabCd--

        // Botlar cesedi raporlar
        val b = body
        if (b != null) {
            val reporter = players
                .filter { !it.isHuman && it.alive }
                .firstOrNull { Random.nextFloat() < (if (it.role == Role.SHINOBI) 0.025f else 0.004f) }
            if (reporter != null) {
                ev.add(Event.Report(reporter, b))
                return ev
            }
        }

        // Bot shinobiler görev yapar
        for (p in players) {
            if (!p.isHuman && p.alive && p.role == Role.SHINOBI &&
                p.tasksDone < TASKS_PER_PLAYER && Random.nextFloat() < 0.018f
            ) {
                p.tasksDone++
                tasksDone++
                ev.add(Event.TaskDone(p))
            }
        }

        // Bot sabotajcılar
        val botSabs = players.filter { !it.isHuman && it.alive && it.role == Role.SABOTAJCI }
        if (botSabs.isNotEmpty()) {
            if (botKillCd > 0) botKillCd--
            if (botSabCd > 0) botSabCd--

            if (botKillCd <= 0 && body == null) {
                val victims = players.filter { it.alive && it.role == Role.SHINOBI }
                if (victims.isNotEmpty()) {
                    val v = victims.random()
                    val k = botSabs.random()
                    v.alive = false
                    body = v
                    killer = k
                    botKillCd = Random.nextInt(35, 55)
                    ev.add(Event.Kill(v, k))
                }
            }
            if (botSabCd <= 0 && tasksDone > 0) {
                loseTasks(2)
                botSabCd = Random.nextInt(50, 80)
                ev.add(Event.Sabotage(botSabs.random()))
            }
        }

        check(ev)
        return ev
    }

    // ---------- Oyuncu aksiyonları ----------
    fun humanTaskDone(): List<Event> {
        val ev = mutableListOf<Event>()
        if (human.role == Role.SHINOBI && human.tasksDone < TASKS_PER_PLAYER) {
            human.tasksDone++
            tasksDone++
            ev.add(Event.TaskDone(human))
        }
        check(ev)
        return ev
    }

    fun humanKill(target: Player): List<Event> {
        val ev = mutableListOf<Event>()
        target.alive = false
        body = target
        killer = human
        humanKillCd = 30
        ev.add(Event.Kill(target, human))
        check(ev)
        return ev
    }

    fun humanSabotage(): List<Event> {
        val ev = mutableListOf<Event>()
        loseTasks(2)
        humanSabCd = 25
        ev.add(Event.Sabotage(human))
        return ev
    }

    // ---------- Toplantı ----------
    private fun statement(bot: Player): String {
        val others = players.filter { it.alive && it.id != bot.id }
        if (others.isEmpty()) return "..."
        if (Random.nextFloat() < 0.12f) return neutralLines.random()

        val target: Player
        if (bot.role == Role.SABOTAJCI) {
            val crew = others.filter { it.role == Role.SHINOBI }
            target = (if (crew.isEmpty()) others else crew).random()
        } else {
            val k = killer
            target = if (k != null && k.alive && k.id != bot.id && Random.nextFloat() < 0.4f) {
                k
            } else {
                others.random()
            }
        }
        suspicion[target.id] = (suspicion[target.id] ?: 0) + 1
        return accuseLines.random().replace("{n}", target.name)
    }

    fun discussion(caller: Player): List<Pair<Player, String>> {
        suspicion.clear()
        val out = mutableListOf<Pair<Player, String>>()
        val bots = players.filter { !it.isHuman && it.alive }.shuffled()
        val b = body

        if (!caller.isHuman) {
            val intro = if (b != null) {
                "Cesedi ben buldum! ${b.name} artık aramızda değil."
            } else {
                "Acil toplantı çağırdım, bir şeyler ters gidiyor!"
            }
            out.add(Pair(caller, intro))
        }
        for (bot in bots) {
            out.add(Pair(bot, statement(bot)))
        }
        for (bot in bots) {
            if ((suspicion[bot.id] ?: 0) > 0 && Random.nextFloat() < 0.55f) {
                out.add(Pair(bot, defendLines.random()))
            }
        }
        return out
    }

    private fun botVote(bot: Player): Int {
        val cands = players.filter { it.alive && it.id != bot.id }
        if (cands.isEmpty()) return -1
        if (bot.role == Role.SABOTAJCI) {
            val crew = cands.filter { it.role == Role.SHINOBI }
            val top = crew.maxByOrNull { suspicion[it.id] ?: 0 }
            if (top != null && (suspicion[top.id] ?: 0) > 0 && Random.nextFloat() < 0.6f) return top.id
            return if (crew.isEmpty()) -1 else crew.random().id
        }
        val top = cands.maxByOrNull { suspicion[it.id] ?: 0 }
        if (top != null && (suspicion[top.id] ?: 0) >= 2 && Random.nextFloat() < 0.7f) return top.id
        if (Random.nextFloat() < 0.25f) return -1
        return cands.random().id
    }

    private fun nameOf(id: Int): String = players.first { it.id == id }.name

    fun resolve(humanVote: Int?): MeetingResult {
        val votes = mutableMapOf<Int, Int>()
        val lines = mutableListOf<String>()

        fun cast(voter: Player, target: Int) {
            votes[target] = (votes[target] ?: 0) + 1
            val label = if (target == -1) "Pas geçti" else nameOf(target)
            lines.add("${voter.name} → $label")
        }

        if (humanVote != null && human.alive) {
            if (humanVote != -1) suspicion[humanVote] = (suspicion[humanVote] ?: 0) + 1
            cast(human, humanVote)
        }
        for (bot in players.filter { !it.isHuman && it.alive }.shuffled()) {
            cast(bot, botVote(bot))
        }

        val real = votes.filterKeys { it != -1 }
        val top = real.maxByOrNull { it.value }
        val skips = votes[-1] ?: 0
        val tie = top != null && real.count { it.value == top.value } > 1
        val ejected: Player? =
            if (top != null && !tie && top.value > skips) players.first { it.id == top.key } else null

        val msg: String
        if (ejected != null) {
            ejected.alive = false
            ejected.revealed = true
            val r = if (ejected.role == Role.SABOTAJCI) "🗡️ SABOTAJCI" else "🥷 Shinobi (masum)"
            msg = "${ejected.name} dışarı atıldı.\nRolü: $r"
        } else {
            msg = "Oylama sonuçsuz. Kimse atılmadı."
        }

        body = null
        killer = null
        botKillCd = maxOf(botKillCd, 25)
        botSabCd = maxOf(botSabCd, 30)
        humanKillCd = maxOf(humanKillCd, 20)
        return MeetingResult(lines.joinToString("\n"), msg, ejected)
    }
}
