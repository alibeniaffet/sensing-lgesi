package com.sensei.hiddenmission

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

enum class Phase { MENU, ROOM, ROLE, PLAY, MEETING, END }

class MainActivity : AppCompatActivity() {

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("sensei", Context.MODE_PRIVATE) }

    private var phase = Phase.MENU
    private var game: Game? = null
    private var dialog: AlertDialog? = null
    private var playerName = "Shinobi"
    private var lastBots: List<String> = emptyList()
    private var roomNames: List<String> = emptyList()
    private var roomBots = 5
    private var news = ""
    private val taskDone = BooleanArray(3)
    private val taskNames = listOf(
        "🔧 Kablo Panelini Onar",
        "⚡ Enerji Çekirdeğini Kontrol Et",
        "📡 Sinyal Sistemini Çalıştır"
    )

    // Oyun ekranı referansları
    private lateinit var pbar: ProgressBar
    private lateinit var progTv: TextView
    private lateinit var newsTv: TextView
    private lateinit var playersTv: TextView
    private lateinit var killBtn: Button
    private lateinit var sabBtn: Button
    private lateinit var reportBtn: Button
    private lateinit var meetBtn: Button
    private val taskBtns = arrayOfNulls<Button>(3)

    // Toplantı ekranı referansları
    private lateinit var chatBox: LinearLayout
    private lateinit var voteBox: LinearLayout
    private lateinit var meetScroll: ScrollView

    private val ticker = object : Runnable {
        override fun run() {
            onTick()
            if (phase == Phase.PLAY) handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        playerName = prefs.getString("name", "Shinobi") ?: "Shinobi"
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                onBack()
            }
        })
        home()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        closeDialogs()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- yardımcılar

    private fun screen(build: LinearLayout.() -> Unit): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(24), dp(20), dp(24))
        col.build()
        val sv = ScrollView(this)
        sv.setBackgroundColor(C.BG)
        sv.isFillViewport = true
        sv.clipToPadding = false
        sv.addView(col, ViewGroup.LayoutParams(MP, WC))
        ViewCompat.setOnApplyWindowInsetsListener(sv) { v, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        setContentView(sv)
        return sv
    }

    private fun closeDialogs() {
        val d = dialog
        dialog = null
        d?.dismiss()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun roleName(r: Role) = if (r == Role.SABOTAJCI) "🗡️ Sabotajcı" else "🥷 Shinobi"

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        closeDialogs()
    }

    private fun onBack() {
        when (phase) {
            Phase.MENU -> finish()
            Phase.ROOM, Phase.END -> home()
            else -> AlertDialog.Builder(this)
                .setTitle("Oyundan çık?")
                .setMessage("Mevcut oyun kaybedilecek.")
                .setPositiveButton("Çık") { _, _ -> home() }
                .setNegativeButton("Devam et", null)
                .show()
        }
    }

    // ---------------------------------------------------------------- ana menü

    private fun home() {
        cleanup()
        game = null
        phase = Phase.MENU

        val nameInput = EditText(this)
        nameInput.setText(playerName)
        nameInput.hint = "Takma adın"
        nameInput.setTextColor(Color.WHITE)
        nameInput.setHintTextColor(C.MUTED)
        nameInput.gravity = Gravity.CENTER
        nameInput.background = roundBg(C.PANEL)
        nameInput.setPadding(dp(14), dp(12), dp(14), dp(12))
        nameInput.filters = arrayOf(InputFilter.LengthFilter(12))
        nameInput.setSingleLine()

        fun saveName() {
            val n = nameInput.text.toString().trim()
            playerName = if (n.isEmpty()) "Shinobi" else n
            prefs.edit().putString("name", playerName).apply()
        }

        val wins = prefs.getInt("wins", 0)
        val games = prefs.getInt("games", 0)

        screen {
            addView(txt("🥷", 64f))
            addView(txt("SENSEI", 38f, Color.WHITE, true))
            addView(txt("GİZLİ GÖREV", 24f, C.ACCENT, true))
            addView(txt("Görevlerini tamamla, sabotajcıyı bul!", 15f, C.MUTED))
            val lpName = LinearLayout.LayoutParams(MP, WC)
            lpName.topMargin = dp(16)
            addView(nameInput, lpName)
            addView(btn("⚡ Hızlı Oyun (6 kişi)") {
                saveName()
                startGame(Game.BOT_NAMES.shuffled().take(5))
            })
            addView(btn("🎮 Oda Oluştur", C.PANEL2) {
                saveName()
                roomNames = Game.BOT_NAMES.shuffled()
                roomBots = 5
                room((100000..999999).random().toString(), true)
            })
            addView(btn("🚪 Odaya Katıl", C.PANEL2) {
                saveName()
                joinDialog()
            })
            addView(btn("ℹ️ Nasıl Oynanır", C.PANEL2) { howTo() })
            addView(txt("📊 Oynanan: $games  •  Kazanılan: $wins", 14f, C.MUTED))
        }
    }

    private fun howTo() {
        AlertDialog.Builder(this)
            .setTitle("Nasıl oynanır?")
            .setMessage(
                "🥷 Shinobi isen 3 mini görevi tamamla. Ekibin görevleri %100 olursa " +
                    "veya sabotajcılar oylamayla atılırsa kazanırsın.\n\n" +
                    "🗡️ Sabotajcı isen gizlice oyuncuları etkisiz hale getir ve görev " +
                    "ilerlemesini boz. Sayıca ekibe eşit olunca kazanırsın.\n\n" +
                    "🚨 Ceset bulunursa ya da acil toplantı çağrılırsa herkes konuşur, " +
                    "sonra oylama yapılır. En çok oyu alan dışarı atılır.\n\n" +
                    "💀 Öldürülürsen hayalet olarak görevlere devam edebilirsin ama oy kullanamazsın."
            )
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun joinDialog() {
        val input = EditText(this)
        input.hint = "6 haneli oda kodu"
        input.inputType = InputType.TYPE_CLASS_NUMBER
        input.filters = arrayOf(InputFilter.LengthFilter(6))
        AlertDialog.Builder(this)
            .setTitle("Odaya Katıl")
            .setView(input)
            .setPositiveButton("Katıl") { _, _ ->
                val code = input.text.toString()
                if (code.length != 6) {
                    toast("Oda kodu 6 haneli olmalı")
                } else {
                    roomNames = Game.BOT_NAMES.shuffled()
                    roomBots = (4..7).random()
                    room(code, false)
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ---------------------------------------------------------------- lobi

    private fun room(code: String, host: Boolean) {
        cleanup()
        phase = Phase.ROOM
        val list = StringBuilder("👑 $playerName (sen)")
        for (i in 0 until roomBots) list.append("\n🤖 ${roomNames[i]}")

        screen {
            addView(txt("🏯 ODA LOBİSİ", 28f, Color.WHITE, true))
            addView(txt("Oda Kodu", 14f, C.MUTED))
            addView(txt(code, 34f, C.ACCENT, true))
            addView(
                txt(
                    if (host) "Sen odanın sahibisin."
                    else "Demo: online sunucu bağlı değil, botlarla oynuyorsun.",
                    14f, C.MUTED
                )
            )
            val c = card()
            c.addView(txt("👥 Oyuncular: ${roomBots + 1} / 10", 16f, C.AMBER, true))
            val l = txt(list.toString(), 16f)
            l.gravity = Gravity.START
            c.addView(l)
            addView(c)
            if (host) {
                addView(btn("➕ Bot Ekle", C.PANEL2) {
                    if (roomBots < 9) {
                        roomBots++
                        room(code, true)
                    } else {
                        toast("En fazla 10 oyuncu")
                    }
                })
                addView(btn("➖ Bot Çıkar", C.PANEL2) {
                    if (roomBots > 3) {
                        roomBots--
                        room(code, true)
                    } else {
                        toast("En az 4 oyuncu gerekli")
                    }
                })
            }
            addView(btn("▶️ Oyunu Başlat") { startGame(roomNames.take(roomBots)) })
            addView(btn("← Ana Menü", C.PANEL2) { home() })
        }
    }

    // ---------------------------------------------------------------- oyun başlangıcı

    private fun startGame(botNames: List<String>) {
        cleanup()
        lastBots = botNames
        game = Game(playerName, botNames)
        taskDone.fill(false)
        news = ""
        phase = Phase.ROLE
        roleScreen()
    }

    private fun roleScreen() {
        val g = game ?: return
        val sab = g.human.role == Role.SABOTAJCI
        val partners = g.players.filter { it.role == Role.SABOTAJCI && !it.isHuman }
        screen {
            addView(txt("ROLÜN", 16f, C.MUTED))
            addView(
                txt(
                    if (sab) "🗡️ SABOTAJCI" else "🥷 SHINOBİ", 38f,
                    if (sab) C.RED else C.GREEN, true
                )
            )
            addView(
                txt(
                    if (sab) {
                        "Gizlice oyuncuları etkisiz hale getir, görev ilerlemesini boz ve yakalanma!\n" +
                            "Görev butonlarıyla sahte görev yaparak masum görünebilirsin."
                    } else {
                        "3 görevi tamamla, şüpheli davranışları izle ve sabotajcıyı oylamayla bul!"
                    }, 16f
                )
            )
            if (sab && partners.isNotEmpty()) {
                addView(
                    txt("Ortağın: " + partners.joinToString(", ") { it.name }, 16f, C.AMBER, true)
                )
            }
            addView(txt("Toplam oyuncu: ${g.players.size}", 14f, C.MUTED))
            addView(btn("Göreve Başla") {
                phase = Phase.PLAY
                gameScreen()
            })
        }
    }

    // ---------------------------------------------------------------- oyun ekranı

    private fun gameScreen() {
        val g = game ?: return
        cleanup()
        phase = Phase.PLAY
        val sab = g.human.role == Role.SABOTAJCI

        screen {
            addView(txt(roleName(g.human.role), 22f, if (sab) C.RED else C.GREEN, true))

            val c = card()
            progTv = txt("", 15f)
            c.addView(progTv)
            pbar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal)
            pbar.max = 100
            pbar.progressTintList = ColorStateList.valueOf(C.GREEN)
            c.addView(pbar, LinearLayout.LayoutParams(MP, dp(14)))
            newsTv = txt("", 14f, C.AMBER)
            c.addView(newsTv)
            addView(c)

            addView(txt(if (sab) "Sahte görevler (kamuflaj)" else "Görevlerin", 14f, C.MUTED))
            for (i in 0 until 3) {
                val b = btn(taskNames[i], C.PANEL2) { openTask(i) }
                taskBtns[i] = b
                addView(b)
            }

            killBtn = btn("🗡️ Etkisiz Hale Getir", C.RED) { doKill() }
            sabBtn = btn("⚠️ Sabotaj Yap", C.RED) { doSabotage() }
            reportBtn = btn("💀 Ceset Raporla", C.AMBER) { doReport() }
            meetBtn = btn("🚨 ACİL TOPLANTI", C.ACCENT) { doMeeting() }
            addView(killBtn)
            addView(sabBtn)
            addView(reportBtn)
            addView(meetBtn)

            val pc = card()
            playersTv = txt("", 15f)
            playersTv.gravity = Gravity.START
            pc.addView(playersTv)
            addView(pc)

            addView(btn("☠️ Oyundan Çık", C.PANEL2) { onBack() })
        }
        handler.postDelayed(ticker, 1000L)
        refreshGameUi()
    }

    private fun refreshGameUi() {
        val g = game ?: return
        if (phase != Phase.PLAY) return
        val h = g.human
        val pct = if (g.tasksTotal == 0) 0 else (g.tasksDone * 100 / g.tasksTotal).coerceIn(0, 100)
        pbar.progress = pct
        progTv.text = "📋 Ortak görev ilerlemesi: $pct%"
        newsTv.text = if (!h.alive) "👻 Hayaletsin. Görevlere devam edebilirsin." else news

        for (i in 0 until 3) {
            val b = taskBtns[i] ?: continue
            if (taskDone[i]) {
                b.text = "✅ " + taskNames[i]
                b.enable(false)
            } else {
                b.text = taskNames[i]
                b.enable(true)
            }
        }

        val isSab = h.role == Role.SABOTAJCI
        killBtn.visibility = if (isSab && h.alive) View.VISIBLE else View.GONE
        sabBtn.visibility = if (isSab && h.alive) View.VISIBLE else View.GONE
        killBtn.text = if (g.humanKillCd > 0) "🗡️ Etkisiz Hale Getir (${g.humanKillCd}s)" else "🗡️ Etkisiz Hale Getir"
        killBtn.enable(g.humanKillCd <= 0 && g.body == null)
        sabBtn.text = if (g.humanSabCd > 0) "⚠️ Sabotaj Yap (${g.humanSabCd}s)" else "⚠️ Sabotaj Yap"
        sabBtn.enable(g.humanSabCd <= 0)

        reportBtn.visibility = if (h.alive && g.body != null) View.VISIBLE else View.GONE
        meetBtn.visibility = if (h.alive) View.VISIBLE else View.GONE
        meetBtn.text = "🚨 ACİL TOPLANTI (${g.meetingsLeft} hak)"
        meetBtn.enable(g.meetingsLeft > 0)

        playersTv.text = g.players.joinToString("\n") { p ->
            val tag = when {
                p.revealed -> " — " + roleName(p.role)
                isSab && p.role == Role.SABOTAJCI && !p.isHuman -> " — ortağın"
                else -> ""
            }
            (if (p.alive) "🟢 " else "💀 ") + p.name + (if (p.isHuman) " (sen)" else "") + tag
        }
    }

    private fun onTick() {
        val g = game ?: return
        if (phase != Phase.PLAY) return
        val ev = g.tick()
        if (!handleEvents(ev)) refreshGameUi()
    }

    /** true dönerse ekran değişti (toplantı / oyun sonu). */
    private fun handleEvents(events: List<Event>): Boolean {
        val g = game ?: return false
        for (e in events) {
            when (e) {
                is Event.TaskDone -> {}
                is Event.Kill -> {
                    if (e.victim.isHuman) {
                        news = "💀 Etkisiz hale getirildin!"
                        showGhostDialog()
                    } else if (e.killer.isHuman) {
                        news = "🗡️ ${e.victim.name} etkisiz hale getirildi. Ceset bulunmadan uzaklaş!"
                    } else if (g.human.role == Role.SABOTAJCI) {
                        news = "🗡️ Ortağın ${e.killer.name}, ${e.victim.name} adlı oyuncuyu etkisiz hale getirdi."
                    }
                }
                is Event.Sabotage -> {
                    news = if (e.by.isHuman) {
                        "⚠️ Sabotaj yaptın, görev ilerlemesi geriledi."
                    } else {
                        "⚠️ Sabotaj! Görev ilerlemesi geriledi."
                    }
                }
                is Event.Report -> {
                    startMeeting("🚨 ${e.by.name}, ${e.victim.name} adlı oyuncunun cesedini buldu!", e.by)
                    return true
                }
                is Event.GameOver -> {
                    endScreen(e.winner)
                    return true
                }
            }
        }
        return false
    }

    private fun showGhostDialog() {
        closeDialogs()
        dialog = AlertDialog.Builder(this)
            .setTitle("💀 Etkisiz hale getirildin!")
            .setMessage("Artık hayaletsin. Görevlere devam edip ekibe yardım edebilirsin ama oy kullanamazsın.")
            .setPositiveButton("Tamam", null)
            .show()
    }

    // ---------------------------------------------------------------- görevler

    private fun openTask(i: Int) {
        if (phase != Phase.PLAY || taskDone[i]) return
        closeDialogs()
        val m = when (i) {
            0 -> MiniGames.wire(this) { completeTask(i) }
            1 -> MiniGames.memory(this) { completeTask(i) }
            else -> MiniGames.timing(this) { completeTask(i) }
        }
        dialog = AlertDialog.Builder(this)
            .setTitle(taskNames[i])
            .setView(m.view)
            .setNegativeButton("Vazgeç", null)
            .setOnDismissListener { m.stop() }
            .show()
    }

    private fun completeTask(i: Int) {
        closeDialogs()
        val g = game ?: return
        if (phase != Phase.PLAY) return
        taskDone[i] = true
        toast(
            if (g.human.role == Role.SABOTAJCI) "Sahte görev yaptın, kimse şüphelenmedi 😈"
            else "Görev tamamlandı! ✅"
        )
        val ev = g.humanTaskDone()
        if (!handleEvents(ev)) refreshGameUi()
    }

    // ---------------------------------------------------------------- aksiyonlar

    private fun doKill() {
        val g = game ?: return
        val targets = g.players.filter { it.alive && it.role == Role.SHINOBI }
        if (targets.isEmpty()) return
        val names = targets.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Kimi etkisiz hale getireceksin?")
            .setItems(names) { _, which ->
                val ev = g.humanKill(targets[which])
                if (!handleEvents(ev)) refreshGameUi()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun doSabotage() {
        val g = game ?: return
        if (g.humanSabCd > 0) return
        val ev = g.humanSabotage()
        if (!handleEvents(ev)) refreshGameUi()
    }

    private fun doReport() {
        val g = game ?: return
        val b = g.body ?: return
        startMeeting("🚨 ${g.human.name}, ${b.name} adlı oyuncunun cesedini buldu!", g.human)
    }

    private fun doMeeting() {
        val g = game ?: return
        if (g.meetingsLeft <= 0) return
        g.meetingsLeft--
        startMeeting("📢 ${g.human.name} acil toplantı çağırdı!", g.human)
    }

    // ---------------------------------------------------------------- toplantı

    private fun startMeeting(reason: String, caller: Player) {
        val g = game ?: return
        cleanup()
        phase = Phase.MEETING
        val lines = g.discussion(caller)

        meetScroll = screen {
            addView(txt("🚨 TOPLANTI", 28f, C.AMBER, true))
            addView(txt(reason, 16f))
            chatBox = card()
            addView(chatBox)
            voteBox = LinearLayout(this@MainActivity)
            voteBox.orientation = LinearLayout.VERTICAL
            addView(voteBox, LinearLayout.LayoutParams(MP, WC))
        }

        lines.forEachIndexed { i, pair ->
            handler.postDelayed({ addChat(pair.first, pair.second) }, 900L * (i + 1))
        }
        handler.postDelayed({ showVoting() }, 900L * (lines.size + 1))
    }

    private fun addChat(p: Player, s: String) {
        val t = txt("${p.name}: $s", 15f)
        t.gravity = Gravity.START
        chatBox.addView(t)
        meetScroll.post { meetScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showVoting() {
        val g = game ?: return
        voteBox.removeAllViews()
        if (!g.human.alive) {
            voteBox.addView(txt("👻 Hayalet olarak izliyorsun, oy kullanamazsın.", 15f, C.MUTED))
            voteBox.addView(btn("Sonucu Gör") { finishMeeting(null) })
            return
        }
        voteBox.addView(txt("🗳️ Kimi dışarı atacaksın?", 18f, C.AMBER, true))
        for (p in g.players.filter { it.alive && !it.isHuman }) {
            voteBox.addView(btn("👤 ${p.name}", C.PANEL2) { finishMeeting(p.id) })
        }
        voteBox.addView(btn("⏭️ Pas Geç", C.PANEL2) { finishMeeting(-1) })
        meetScroll.post { meetScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun finishMeeting(humanVote: Int?) {
        val g = game ?: return
        val res = g.resolve(humanVote)
        voteBox.removeAllViews()
        voteBox.addView(txt("📊 Oylar", 18f, C.AMBER, true))
        val s = txt(res.summary, 14f)
        s.gravity = Gravity.START
        voteBox.addView(s)
        voteBox.addView(txt(res.message, 18f, Color.WHITE, true))
        voteBox.addView(btn("Devam") { afterMeeting() })
        meetScroll.post { meetScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun afterMeeting() {
        val g = game ?: return
        val w = g.winner()
        if (w != Winner.NONE) {
            endScreen(w)
        } else {
            news = ""
            gameScreen()
        }
    }

    // ---------------------------------------------------------------- oyun sonu

    private fun endScreen(w: Winner) {
        val g = game ?: return
        if (phase == Phase.END) return
        cleanup()
        phase = Phase.END

        val humanWon = (w == Winner.SHINOBI && g.human.role == Role.SHINOBI) ||
            (w == Winner.SABOTAJCI && g.human.role == Role.SABOTAJCI)
        prefs.edit()
            .putInt("games", prefs.getInt("games", 0) + 1)
            .putInt("wins", prefs.getInt("wins", 0) + (if (humanWon) 1 else 0))
            .apply()

        val summary = g.players.joinToString("\n") { p ->
            (if (p.role == Role.SABOTAJCI) "🗡️ " else "🥷 ") + p.name +
                (if (p.isHuman) " (sen)" else "") +
                (if (p.alive) " — hayatta" else " — elendi")
        }

        screen {
            addView(txt(if (humanWon) "🏆" else "💀", 64f))
            addView(
                txt(
                    if (humanWon) "KAZANDIN!" else "KAYBETTİN", 32f,
                    if (humanWon) C.GREEN else C.RED, true
                )
            )
            addView(
                txt(
                    if (w == Winner.SHINOBI) "Shinobiler kazandı!" else "Sabotajcılar kazandı!",
                    18f, C.AMBER, true
                )
            )
            val c = card()
            c.addView(txt("Roller", 16f, C.MUTED))
            val l = txt(summary, 15f)
            l.gravity = Gravity.START
            c.addView(l)
            addView(c)
            addView(btn("🔁 Tekrar Oyna") {
                startGame(Game.BOT_NAMES.shuffled().take(lastBots.size))
            })
            addView(btn("🏠 Ana Menü", C.PANEL2) { home() })
        }
    }
}
