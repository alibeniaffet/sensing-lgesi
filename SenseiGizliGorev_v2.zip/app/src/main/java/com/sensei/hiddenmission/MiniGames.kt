package com.sensei.hiddenmission

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import kotlin.random.Random

class Mini(val view: View, val stop: () -> Unit = {})

class TimingBar(ctx: Context) : View(ctx) {
    var pos = 0f
    var zoneStart = 0.4f
    var zoneEnd = 0.6f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = Color.parseColor("#1F2940")
        canvas.drawRoundRect(0f, 0f, w, h, h / 4, h / 4, p)
        p.color = Color.parseColor("#2EB67D")
        canvas.drawRect(zoneStart * w, 0f, zoneEnd * w, h, p)
        p.color = Color.WHITE
        canvas.drawRect(pos * w - 5f, 0f, pos * w + 5f, h, p)
    }
}

object MiniGames {

    private fun box(ctx: Context): LinearLayout {
        val b = LinearLayout(ctx)
        b.orientation = LinearLayout.VERTICAL
        b.setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(16), ctx.dp(8))
        return b
    }

    private fun cell(ctx: Context, h: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, ctx.dp(h), 1f)
        lp.setMargins(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
        return lp
    }

    // 🔧 Kablo paneli: 1'den 6'ya sırayla dokun
    fun wire(ctx: Context, onDone: () -> Unit): Mini {
        val box = box(ctx)
        val info = ctx.txt("Sayılara 1'den 6'ya kadar sırayla dokun.", 15f)
        box.addView(info)
        val nums = (1..6).shuffled()
        var next = 1
        val buttons = ArrayList<Button>()

        for (r in 0 until 2) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until 3) {
                val n = nums[r * 3 + c]
                val b = ctx.btn("$n", C.PANEL2) {}
                b.textSize = 24f
                b.layoutParams = cell(ctx, 80)
                b.setOnClickListener {
                    if (n == next) {
                        b.isEnabled = false
                        b.background = ctx.roundBg(C.GREEN)
                        next++
                        info.text = "Doğru! ($n)"
                        if (next > 6) onDone()
                    } else {
                        next = 1
                        for (x in buttons) {
                            x.isEnabled = true
                            x.background = ctx.roundBg(C.PANEL2)
                        }
                        info.text = "❌ Yanlış sıra! Baştan başla."
                        it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    }
                }
                buttons.add(b)
                row.addView(b)
            }
            box.addView(row)
        }
        return Mini(box)
    }

    // ⚡ Enerji çekirdeği: renk dizisini hatırla
    fun memory(ctx: Context, onDone: () -> Unit): Mini {
        val h = Handler(Looper.getMainLooper())
        val dim = listOf("#3B2F7F", "#7F2F3B", "#2F7F4B", "#7F6A2F").map { Color.parseColor(it) }
        val bright = listOf("#6C63FF", "#E5484D", "#2EB67D", "#F5A524").map { Color.parseColor(it) }
        val box = box(ctx)
        val info = ctx.txt("👀 Diziyi izle...", 15f)
        box.addView(info)

        var seq = List(4) { Random.nextInt(4) }
        var pos = 0
        var locked = true
        val pads = ArrayList<Button>()

        fun flash(i: Int) {
            pads[i].background = ctx.roundBg(bright[i])
            h.postDelayed({ pads[i].background = ctx.roundBg(dim[i]) }, 400L)
        }

        fun play() {
            locked = true
            pos = 0
            info.text = "👀 Diziyi izle..."
            seq.forEachIndexed { k, i -> h.postDelayed({ flash(i) }, 700L * (k + 1)) }
            h.postDelayed({
                locked = false
                info.text = "Şimdi sen tekrarla!"
            }, 700L * (seq.size + 1))
        }

        for (r in 0 until 2) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until 2) {
                val i = r * 2 + c
                val b = ctx.btn("", C.PANEL2) {}
                b.background = ctx.roundBg(dim[i])
                b.layoutParams = cell(ctx, 90)
                b.setOnClickListener {
                    if (!locked) {
                        flash(i)
                        if (i == seq[pos]) {
                            pos++
                            if (pos >= seq.size) {
                                locked = true
                                onDone()
                            }
                        } else {
                            locked = true
                            info.text = "❌ Yanlış! Yeni dizi geliyor..."
                            seq = List(4) { Random.nextInt(4) }
                            h.postDelayed({ play() }, 900L)
                        }
                    }
                }
                pads.add(b)
                row.addView(b)
            }
            box.addView(row)
        }
        h.postDelayed({ play() }, 500L)
        return Mini(box) { h.removeCallbacksAndMessages(null) }
    }

    // 📡 Sinyal sistemi: çizgi yeşil bölgedeyken kilitle
    fun timing(ctx: Context, onDone: () -> Unit): Mini {
        val h = Handler(Looper.getMainLooper())
        val box = box(ctx)
        val info = ctx.txt("Çizgi yeşil bölgedeyken KİLİTLE'ye bas! (0/3)", 15f)
        box.addView(info)

        val bar = TimingBar(ctx)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(44))
        lp.topMargin = ctx.dp(16)
        lp.bottomMargin = ctx.dp(8)
        bar.layoutParams = lp
        box.addView(bar)

        var hits = 0
        var dir = 1f
        var speed = 0.012f

        val loop = object : Runnable {
            override fun run() {
                bar.pos += dir * speed
                if (bar.pos >= 1f) {
                    bar.pos = 1f
                    dir = -1f
                } else if (bar.pos <= 0f) {
                    bar.pos = 0f
                    dir = 1f
                }
                bar.invalidate()
                h.postDelayed(this, 16L)
            }
        }

        val lock = ctx.btn("🔒 KİLİTLE", C.GREEN) {
            if (bar.pos >= bar.zoneStart && bar.pos <= bar.zoneEnd) {
                hits++
                speed += 0.004f
                val s = Random.nextFloat() * 0.6f + 0.05f
                bar.zoneStart = s
                bar.zoneEnd = s + 0.2f
                info.text = "✅ Harika! ($hits/3)"
                if (hits >= 3) {
                    h.removeCallbacksAndMessages(null)
                    onDone()
                }
            } else {
                hits = 0
                speed = 0.012f
                info.text = "❌ Kaçırdın! Baştan. (0/3)"
            }
        }
        box.addView(lock)
        h.post(loop)
        return Mini(box) { h.removeCallbacksAndMessages(null) }
    }
}
