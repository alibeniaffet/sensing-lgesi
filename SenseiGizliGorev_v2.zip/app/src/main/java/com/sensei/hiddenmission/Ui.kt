package com.sensei.hiddenmission

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val BG = Color.parseColor("#080B14")
    val PANEL = Color.parseColor("#141B2D")
    val PANEL2 = Color.parseColor("#1F2940")
    val ACCENT = Color.parseColor("#6C63FF")
    val RED = Color.parseColor("#E5484D")
    val GREEN = Color.parseColor("#2EB67D")
    val AMBER = Color.parseColor("#F5A524")
    val MUTED = Color.parseColor("#9AA4BF")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.roundBg(color: Int, radius: Int = 14): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    d.cornerRadius = dp(radius).toFloat()
    return d
}

fun Context.txt(
    s: String,
    size: Float = 16f,
    color: Int = Color.WHITE,
    bold: Boolean = false
): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = size
    t.setTextColor(color)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(6), dp(8), dp(6), dp(8))
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.btn(s: String, color: Int = C.ACCENT, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = s
    b.textSize = 16f
    b.isAllCaps = false
    b.setTextColor(Color.WHITE)
    b.background = roundBg(color)
    b.setPadding(dp(16), dp(14), dp(16), dp(14))
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(10)
    b.layoutParams = lp
    b.setOnClickListener {
        it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        onClick()
    }
    return b
}

fun Button.enable(on: Boolean) {
    isEnabled = on
    alpha = if (on) 1f else 0.4f
}

fun Context.card(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.background = roundBg(C.PANEL, 16)
    l.setPadding(dp(12), dp(10), dp(12), dp(10))
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(10)
    l.layoutParams = lp
    return l
}
